
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nadiencorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.nadiencorp.item.TransmisorItem;
import net.mcreator.nadiencorp.item.SemillaItem;
import net.mcreator.nadiencorp.item.RickrollItem;
import net.mcreator.nadiencorp.item.PlanosItem;
import net.mcreator.nadiencorp.item.PicoDePanItem;
import net.mcreator.nadiencorp.item.PepitaestrellaItem;
import net.mcreator.nadiencorp.item.PatricioItem;
import net.mcreator.nadiencorp.item.PanItem;
import net.mcreator.nadiencorp.item.PalaDePanItem;
import net.mcreator.nadiencorp.item.NadienItem;
import net.mcreator.nadiencorp.item.MunecoItem;
import net.mcreator.nadiencorp.item.MinireactorItem;
import net.mcreator.nadiencorp.item.MinipirtalItem;
import net.mcreator.nadiencorp.item.HachaDePanItem;
import net.mcreator.nadiencorp.item.EstrellitaItem;
import net.mcreator.nadiencorp.item.EspadadepanItem;
import net.mcreator.nadiencorp.item.EasterEggItem;
import net.mcreator.nadiencorp.item.CombustibleItem;
import net.mcreator.nadiencorp.item.CalaveraItem;
import net.mcreator.nadiencorp.item.CajitaFelizItem;
import net.mcreator.nadiencorp.item.CajitaFelizComidaItem;
import net.mcreator.nadiencorp.item.BrujulaItem;
import net.mcreator.nadiencorp.item.AzadaDePanItem;
import net.mcreator.nadiencorp.item.AntiMateriaItem;
import net.mcreator.nadiencorp.item.AlmaItem;
import net.mcreator.nadiencorp.NadiencorpMod;

public class NadiencorpModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NadiencorpMod.MODID);
	public static final RegistryObject<Item> PATRICIO = REGISTRY.register("patricio", () -> new PatricioItem());
	public static final RegistryObject<Item> ESTRELLITA = REGISTRY.register("estrellita", () -> new EstrellitaItem());
	public static final RegistryObject<Item> BRUJULA = REGISTRY.register("brujula", () -> new BrujulaItem());
	public static final RegistryObject<Item> CALAVERA = REGISTRY.register("calavera", () -> new CalaveraItem());
	public static final RegistryObject<Item> ANTI_MATERIA = REGISTRY.register("anti_materia", () -> new AntiMateriaItem());
	public static final RegistryObject<Item> ALMA = REGISTRY.register("alma", () -> new AlmaItem());
	public static final RegistryObject<Item> COMBUSTIBLE = REGISTRY.register("combustible", () -> new CombustibleItem());
	public static final RegistryObject<Item> MUNECO = REGISTRY.register("muneco", () -> new MunecoItem());
	public static final RegistryObject<Item> MINIPIRTAL = REGISTRY.register("minipirtal", () -> new MinipirtalItem());
	public static final RegistryObject<Item> MINIREACTOR = REGISTRY.register("minireactor", () -> new MinireactorItem());
	public static final RegistryObject<Item> PLANOS = REGISTRY.register("planos", () -> new PlanosItem());
	public static final RegistryObject<Item> SEMILLA = REGISTRY.register("semilla", () -> new SemillaItem());
	public static final RegistryObject<Item> PEPITAESTRELLA = REGISTRY.register("pepitaestrella", () -> new PepitaestrellaItem());
	public static final RegistryObject<Item> CAJITA_FELIZ = REGISTRY.register("cajita_feliz", () -> new CajitaFelizItem());
	public static final RegistryObject<Item> RICKROLL = REGISTRY.register("rickroll", () -> new RickrollItem());
	public static final RegistryObject<Item> PAN = REGISTRY.register("pan", () -> new PanItem());
	public static final RegistryObject<Item> PICO_DE_PAN = REGISTRY.register("pico_de_pan", () -> new PicoDePanItem());
	public static final RegistryObject<Item> ESPADADEPAN = REGISTRY.register("espadadepan", () -> new EspadadepanItem());
	public static final RegistryObject<Item> PALA_DE_PAN = REGISTRY.register("pala_de_pan", () -> new PalaDePanItem());
	public static final RegistryObject<Item> HACHA_DE_PAN = REGISTRY.register("hacha_de_pan", () -> new HachaDePanItem());
	public static final RegistryObject<Item> AZADA_DE_PAN = REGISTRY.register("azada_de_pan", () -> new AzadaDePanItem());
	public static final RegistryObject<Item> EASTER_EGG = REGISTRY.register("easter_egg", () -> new EasterEggItem());
	public static final RegistryObject<Item> MENA_DE_PAN = block(NadiencorpModBlocks.MENA_DE_PAN);
	public static final RegistryObject<Item> CAJITA_FELIZ_COMIDA = REGISTRY.register("cajita_feliz_comida", () -> new CajitaFelizComidaItem());
	public static final RegistryObject<Item> NADIEN = REGISTRY.register("nadien", () -> new NadienItem());
	public static final RegistryObject<Item> TRANSMISOR = REGISTRY.register("transmisor", () -> new TransmisorItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
