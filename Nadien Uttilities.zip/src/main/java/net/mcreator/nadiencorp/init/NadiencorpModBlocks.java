
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nadiencorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.nadiencorp.block.MenaDePanBlock;
import net.mcreator.nadiencorp.NadiencorpMod;

public class NadiencorpModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NadiencorpMod.MODID);
	public static final RegistryObject<Block> MENA_DE_PAN = REGISTRY.register("mena_de_pan", () -> new MenaDePanBlock());
}
