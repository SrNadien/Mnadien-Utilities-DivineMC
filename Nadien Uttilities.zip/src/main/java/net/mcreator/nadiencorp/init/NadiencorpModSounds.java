
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nadiencorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.nadiencorp.NadiencorpMod;

public class NadiencorpModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, NadiencorpMod.MODID);
	public static final RegistryObject<SoundEvent> CAJITAFELIZMCCACO = REGISTRY.register("cajitafelizmccaco", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("nadiencorp", "cajitafelizmccaco")));
	public static final RegistryObject<SoundEvent> RICKROLL = REGISTRY.register("rickroll", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("nadiencorp", "rickroll")));
}
