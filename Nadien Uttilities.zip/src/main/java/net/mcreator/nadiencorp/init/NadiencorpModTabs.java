
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nadiencorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.nadiencorp.NadiencorpMod;

public class NadiencorpModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NadiencorpMod.MODID);
	public static final RegistryObject<CreativeModeTab> DIVINE_MC = REGISTRY.register("divine_mc",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nadiencorp.divine_mc")).icon(() -> new ItemStack(NadiencorpModItems.ESTRELLITA.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NadiencorpModItems.PATRICIO.get());
				tabData.accept(NadiencorpModItems.BRUJULA.get());
				tabData.accept(NadiencorpModItems.CALAVERA.get());
				tabData.accept(NadiencorpModItems.ANTI_MATERIA.get());
				tabData.accept(NadiencorpModItems.ALMA.get());
				tabData.accept(NadiencorpModItems.COMBUSTIBLE.get());
				tabData.accept(NadiencorpModItems.MUNECO.get());
				tabData.accept(NadiencorpModItems.MINIPIRTAL.get());
				tabData.accept(NadiencorpModItems.MINIREACTOR.get());
				tabData.accept(NadiencorpModItems.PLANOS.get());
				tabData.accept(NadiencorpModItems.SEMILLA.get());
				tabData.accept(NadiencorpModItems.PEPITAESTRELLA.get());
				tabData.accept(NadiencorpModItems.CAJITA_FELIZ.get());
				tabData.accept(NadiencorpModItems.RICKROLL.get());
				tabData.accept(NadiencorpModItems.PAN.get());
				tabData.accept(NadiencorpModItems.PICO_DE_PAN.get());
				tabData.accept(NadiencorpModItems.ESPADADEPAN.get());
				tabData.accept(NadiencorpModItems.PALA_DE_PAN.get());
				tabData.accept(NadiencorpModItems.HACHA_DE_PAN.get());
				tabData.accept(NadiencorpModItems.AZADA_DE_PAN.get());
				tabData.accept(NadiencorpModItems.EASTER_EGG.get());
				tabData.accept(NadiencorpModBlocks.MENA_DE_PAN.get().asItem());
				tabData.accept(NadiencorpModItems.CAJITA_FELIZ_COMIDA.get());
				tabData.accept(NadiencorpModItems.NADIEN.get());
				tabData.accept(NadiencorpModItems.TRANSMISOR.get());
			})

					.build());
}
